package bot;

import net.dv8tion.jda.core.AccountType;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.JDABuilder;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.User;
import net.dv8tion.jda.core.events.message.MessageReceivedEvent;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class DiscordBot extends ListenerAdapter {

    public static void main(String[] args) {
        
        //Attempt to login our bot, if it didn't work, we catch the exception and print the stack trace.
        try {
            //The JDA object is the core of the library. We must make a JDA object that contains our Bot token.
            //Creating a JDA object with a valid Token will automatically login the Bot in when this program is ran.
            //Make sure to replace the .setToken(Parameter) with your own bot token! 
            JDA jda = new JDABuilder(AccountType.BOT).setToken("NDI3NTcwMjI0NzEyMTIyMzk4.DZnHtA.RYQPqh5J7iWLQsguZY9ujxl6E00").addEventListener(new DiscordBot()).buildBlocking();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
@Override
public void onMessageReceived(MessageReceivedEvent event) {
        
        MessageChannel channel = event.getChannel(); //this returns an object representing the channel that the event was fired.
        String msg = event.getMessage().getContentDisplay(); //this returns a String representation of the event.
        //User user = event.getAuthor();  //this returns the User that fired the event.
        //Boolean bot = user.isBot(); //this returns if the User that fired the event was a bot or not (prevents bots replying to bots!)
        
        if (msg.equalsIgnoreCase("hi")) {
            channel.sendMessage("Hello!").queue(); //Sends the message to the channel.
        }      
    }
}
