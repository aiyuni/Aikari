package bot;

import net.dv8tion.jda.core.AccountType;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.JDABuilder;
import net.dv8tion.jda.core.hooks.ListenerAdapter;

public class DiscordBot extends ListenerAdapter {

    public static void main(String[] args) {
        
        //Attempt to login our bot, if it didn't work, we catch the exception and print the stack trace.
        try {
            //The JDA object is the core of the library. We must make a JDA object that contains our Bot token.
            //Creating a JDA object with a valid Token will automatically login the Bot in when this program is ran.
            //Make sure to replace the .setToken(Parameter) with your own bot token! 
            JDA jda = new JDABuilder(AccountType.BOT).setToken("YOUR BOT TOKEN HERE").addEventListener(new DiscordBot()).buildBlocking();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}